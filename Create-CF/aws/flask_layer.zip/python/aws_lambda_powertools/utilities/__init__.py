"""General utilities for Powertools"""
